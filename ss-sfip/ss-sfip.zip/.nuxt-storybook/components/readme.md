# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<NuxtLogo>` | `<nuxt-logo>` (components/NuxtLogo.vue)
- `<Tutorial>` | `<tutorial>` (components/Tutorial.vue)
- `<VuetifyLogo>` | `<vuetify-logo>` (components/VuetifyLogo.vue)
- `<CardAnalyticCardVersionOne>` | `<card-analytic-card-version-one>` (components/card/AnalyticCardVersionOne.vue)
- `<CardAnalyticCardVersionTwo>` | `<card-analytic-card-version-two>` (components/card/AnalyticCardVersionTwo.vue)
- `<CardAvatarGroupCard>` | `<card-avatar-group-card>` (components/card/AvatarGroupCard.vue)
- `<CardBasicInfoCard>` | `<card-basic-info-card>` (components/card/BasicInfoCard.vue)
- `<CardChartCard>` | `<card-chart-card>` (components/card/ChartCard.vue)
- `<CardCryptoCurrencyCard>` | `<card-crypto-currency-card>` (components/card/CryptoCurrencyCard.vue)
- `<CardDonationCard>` | `<card-donation-card>` (components/card/DonationCard.vue)
- `<CardLmsCard>` | `<card-lms-card>` (components/card/LmsCard.vue)
- `<CardPriceCard>` | `<card-price-card>` (components/card/PriceCard.vue)
- `<CardTestCard>` | `<card-test-card>` (components/card/TestCard.vue)
- `<StorybookButton>` | `<storybook-button>` (components/Storybook/Button.vue)
- `<StorybookTest>` | `<storybook-test>` (components/Storybook/Test.vue)
- `<CardListCard>` | `<card-list-card>` (components/card/listCard/ListCard.vue)
- `<CardListCardRow>` | `<card-list-card-row>` (components/card/listCard/ListCardRow.vue)
- `<CardListCardThree>` | `<card-list-card-three>` (components/card/listCard/ListCardThree.vue)
- `<CardListCardTwo>` | `<card-list-card-two>` (components/card/listCard/ListCardTwo.vue)
