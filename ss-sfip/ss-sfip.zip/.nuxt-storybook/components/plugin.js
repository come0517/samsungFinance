import Vue from 'vue'
import { wrapFunctional } from './utils'

const components = {
  NuxtLogo: () => import('../..\\components\\NuxtLogo.vue' /* webpackChunkName: "components/nuxt-logo" */).then(c => wrapFunctional(c.default || c)),
  Tutorial: () => import('../..\\components\\Tutorial.vue' /* webpackChunkName: "components/tutorial" */).then(c => wrapFunctional(c.default || c)),
  VuetifyLogo: () => import('../..\\components\\VuetifyLogo.vue' /* webpackChunkName: "components/vuetify-logo" */).then(c => wrapFunctional(c.default || c)),
  CardAnalyticCardVersionOne: () => import('../..\\components\\card\\AnalyticCardVersionOne.vue' /* webpackChunkName: "components/card-analytic-card-version-one" */).then(c => wrapFunctional(c.default || c)),
  CardAnalyticCardVersionTwo: () => import('../..\\components\\card\\AnalyticCardVersionTwo.vue' /* webpackChunkName: "components/card-analytic-card-version-two" */).then(c => wrapFunctional(c.default || c)),
  CardAvatarGroupCard: () => import('../..\\components\\card\\AvatarGroupCard.vue' /* webpackChunkName: "components/card-avatar-group-card" */).then(c => wrapFunctional(c.default || c)),
  CardBasicInfoCard: () => import('../..\\components\\card\\BasicInfoCard.vue' /* webpackChunkName: "components/card-basic-info-card" */).then(c => wrapFunctional(c.default || c)),
  CardChartCard: () => import('../..\\components\\card\\ChartCard.vue' /* webpackChunkName: "components/card-chart-card" */).then(c => wrapFunctional(c.default || c)),
  CardCryptoCurrencyCard: () => import('../..\\components\\card\\CryptoCurrencyCard.vue' /* webpackChunkName: "components/card-crypto-currency-card" */).then(c => wrapFunctional(c.default || c)),
  CardDonationCard: () => import('../..\\components\\card\\DonationCard.vue' /* webpackChunkName: "components/card-donation-card" */).then(c => wrapFunctional(c.default || c)),
  CardLmsCard: () => import('../..\\components\\card\\LmsCard.vue' /* webpackChunkName: "components/card-lms-card" */).then(c => wrapFunctional(c.default || c)),
  CardPriceCard: () => import('../..\\components\\card\\PriceCard.vue' /* webpackChunkName: "components/card-price-card" */).then(c => wrapFunctional(c.default || c)),
  CardTestCard: () => import('../..\\components\\card\\TestCard.vue' /* webpackChunkName: "components/card-test-card" */).then(c => wrapFunctional(c.default || c)),
  StorybookButton: () => import('../..\\components\\Storybook\\Button.vue' /* webpackChunkName: "components/storybook-button" */).then(c => wrapFunctional(c.default || c)),
  StorybookTest: () => import('../..\\components\\Storybook\\Test.vue' /* webpackChunkName: "components/storybook-test" */).then(c => wrapFunctional(c.default || c)),
  CardListCard: () => import('../..\\components\\card\\listCard\\ListCard.vue' /* webpackChunkName: "components/card-list-card" */).then(c => wrapFunctional(c.default || c)),
  CardListCardRow: () => import('../..\\components\\card\\listCard\\ListCardRow.vue' /* webpackChunkName: "components/card-list-card-row" */).then(c => wrapFunctional(c.default || c)),
  CardListCardThree: () => import('../..\\components\\card\\listCard\\ListCardThree.vue' /* webpackChunkName: "components/card-list-card-three" */).then(c => wrapFunctional(c.default || c)),
  CardListCardTwo: () => import('../..\\components\\card\\listCard\\ListCardTwo.vue' /* webpackChunkName: "components/card-list-card-two" */).then(c => wrapFunctional(c.default || c))
}

for (const name in components) {
  Vue.component(name, components[name])
  Vue.component('Lazy' + name, components[name])
}
