import { wrapFunctional } from './utils'

export { default as NuxtLogo } from '../..\\components\\NuxtLogo.vue'
export { default as Tutorial } from '../..\\components\\Tutorial.vue'
export { default as VuetifyLogo } from '../..\\components\\VuetifyLogo.vue'
export { default as CardAnalyticCardVersionOne } from '../..\\components\\card\\AnalyticCardVersionOne.vue'
export { default as CardAnalyticCardVersionTwo } from '../..\\components\\card\\AnalyticCardVersionTwo.vue'
export { default as CardAvatarGroupCard } from '../..\\components\\card\\AvatarGroupCard.vue'
export { default as CardBasicInfoCard } from '../..\\components\\card\\BasicInfoCard.vue'
export { default as CardChartCard } from '../..\\components\\card\\ChartCard.vue'
export { default as CardCryptoCurrencyCard } from '../..\\components\\card\\CryptoCurrencyCard.vue'
export { default as CardDonationCard } from '../..\\components\\card\\DonationCard.vue'
export { default as CardLmsCard } from '../..\\components\\card\\LmsCard.vue'
export { default as CardPriceCard } from '../..\\components\\card\\PriceCard.vue'
export { default as CardTestCard } from '../..\\components\\card\\TestCard.vue'
export { default as StorybookButton } from '../..\\components\\Storybook\\Button.vue'
export { default as StorybookTest } from '../..\\components\\Storybook\\Test.vue'
export { default as CardListCard } from '../..\\components\\card\\listCard\\ListCard.vue'
export { default as CardListCardRow } from '../..\\components\\card\\listCard\\ListCardRow.vue'
export { default as CardListCardThree } from '../..\\components\\card\\listCard\\ListCardThree.vue'
export { default as CardListCardTwo } from '../..\\components\\card\\listCard\\ListCardTwo.vue'

export const LazyNuxtLogo = import('../..\\components\\NuxtLogo.vue' /* webpackChunkName: "components/nuxt-logo" */).then(c => wrapFunctional(c.default || c))
export const LazyTutorial = import('../..\\components\\Tutorial.vue' /* webpackChunkName: "components/tutorial" */).then(c => wrapFunctional(c.default || c))
export const LazyVuetifyLogo = import('../..\\components\\VuetifyLogo.vue' /* webpackChunkName: "components/vuetify-logo" */).then(c => wrapFunctional(c.default || c))
export const LazyCardAnalyticCardVersionOne = import('../..\\components\\card\\AnalyticCardVersionOne.vue' /* webpackChunkName: "components/card-analytic-card-version-one" */).then(c => wrapFunctional(c.default || c))
export const LazyCardAnalyticCardVersionTwo = import('../..\\components\\card\\AnalyticCardVersionTwo.vue' /* webpackChunkName: "components/card-analytic-card-version-two" */).then(c => wrapFunctional(c.default || c))
export const LazyCardAvatarGroupCard = import('../..\\components\\card\\AvatarGroupCard.vue' /* webpackChunkName: "components/card-avatar-group-card" */).then(c => wrapFunctional(c.default || c))
export const LazyCardBasicInfoCard = import('../..\\components\\card\\BasicInfoCard.vue' /* webpackChunkName: "components/card-basic-info-card" */).then(c => wrapFunctional(c.default || c))
export const LazyCardChartCard = import('../..\\components\\card\\ChartCard.vue' /* webpackChunkName: "components/card-chart-card" */).then(c => wrapFunctional(c.default || c))
export const LazyCardCryptoCurrencyCard = import('../..\\components\\card\\CryptoCurrencyCard.vue' /* webpackChunkName: "components/card-crypto-currency-card" */).then(c => wrapFunctional(c.default || c))
export const LazyCardDonationCard = import('../..\\components\\card\\DonationCard.vue' /* webpackChunkName: "components/card-donation-card" */).then(c => wrapFunctional(c.default || c))
export const LazyCardLmsCard = import('../..\\components\\card\\LmsCard.vue' /* webpackChunkName: "components/card-lms-card" */).then(c => wrapFunctional(c.default || c))
export const LazyCardPriceCard = import('../..\\components\\card\\PriceCard.vue' /* webpackChunkName: "components/card-price-card" */).then(c => wrapFunctional(c.default || c))
export const LazyCardTestCard = import('../..\\components\\card\\TestCard.vue' /* webpackChunkName: "components/card-test-card" */).then(c => wrapFunctional(c.default || c))
export const LazyStorybookButton = import('../..\\components\\Storybook\\Button.vue' /* webpackChunkName: "components/storybook-button" */).then(c => wrapFunctional(c.default || c))
export const LazyStorybookTest = import('../..\\components\\Storybook\\Test.vue' /* webpackChunkName: "components/storybook-test" */).then(c => wrapFunctional(c.default || c))
export const LazyCardListCard = import('../..\\components\\card\\listCard\\ListCard.vue' /* webpackChunkName: "components/card-list-card" */).then(c => wrapFunctional(c.default || c))
export const LazyCardListCardRow = import('../..\\components\\card\\listCard\\ListCardRow.vue' /* webpackChunkName: "components/card-list-card-row" */).then(c => wrapFunctional(c.default || c))
export const LazyCardListCardThree = import('../..\\components\\card\\listCard\\ListCardThree.vue' /* webpackChunkName: "components/card-list-card-three" */).then(c => wrapFunctional(c.default || c))
export const LazyCardListCardTwo = import('../..\\components\\card\\listCard\\ListCardTwo.vue' /* webpackChunkName: "components/card-list-card-two" */).then(c => wrapFunctional(c.default || c))
