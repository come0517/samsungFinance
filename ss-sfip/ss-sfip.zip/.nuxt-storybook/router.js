import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _92205312 = () => interopDefault(import('..\\pages\\inspire.vue' /* webpackChunkName: "pages/inspire" */))
const _2c517816 = () => interopDefault(import('..\\pages\\fund\\list.vue' /* webpackChunkName: "pages/fund/list" */))
const _31847932 = () => interopDefault(import('..\\pages\\app\\apps\\Index.vue' /* webpackChunkName: "pages/app/apps/Index" */))
const _01c60888 = () => interopDefault(import('..\\pages\\app\\apps\\Scrumboard.vue' /* webpackChunkName: "pages/app/apps/Scrumboard" */))
const _fc5cdaf0 = () => interopDefault(import('..\\pages\\app\\charts\\Charts.vue' /* webpackChunkName: "pages/app/charts/Charts" */))
const _0f77cff3 = () => interopDefault(import('..\\pages\\app\\dashboard\\Analytic.vue' /* webpackChunkName: "pages/app/dashboard/Analytic" */))
const _4012dfdc = () => interopDefault(import('..\\pages\\app\\dashboard\\Index.vue' /* webpackChunkName: "pages/app/dashboard/Index" */))
const _4d3987c3 = () => interopDefault(import('..\\pages\\app\\ecommerce\\CartDrawer.vue' /* webpackChunkName: "pages/app/ecommerce/CartDrawer" */))
const _0933e41e = () => interopDefault(import('..\\pages\\app\\ecommerce\\Ecommerce.vue' /* webpackChunkName: "pages/app/ecommerce/Ecommerce" */))
const _8b7e8df2 = () => interopDefault(import('..\\pages\\app\\ecommerce\\EcommerceProductCheckout.vue' /* webpackChunkName: "pages/app/ecommerce/EcommerceProductCheckout" */))
const _79773e91 = () => interopDefault(import('..\\pages\\app\\ecommerce\\EcommerceProductDetails.vue' /* webpackChunkName: "pages/app/ecommerce/EcommerceProductDetails" */))
const _37dd2cdf = () => interopDefault(import('..\\pages\\app\\ecommerce\\EcommerceProductList.vue' /* webpackChunkName: "pages/app/ecommerce/EcommerceProductList" */))
const _a9f3d1a4 = () => interopDefault(import('..\\pages\\app\\pages\\Blank.vue' /* webpackChunkName: "pages/app/pages/Blank" */))
const _7e91bd9e = () => interopDefault(import('..\\pages\\app\\pages\\Pages.vue' /* webpackChunkName: "pages/app/pages/Pages" */))
const _20e408b4 = () => interopDefault(import('..\\pages\\app\\charts\\apexChart\\ApexAreaChart.vue' /* webpackChunkName: "pages/app/charts/apexChart/ApexAreaChart" */))
const _4d8c46c6 = () => interopDefault(import('..\\pages\\app\\charts\\apexChart\\ApexBarChart.vue' /* webpackChunkName: "pages/app/charts/apexChart/ApexBarChart" */))
const _7d710433 = () => interopDefault(import('..\\pages\\app\\charts\\apexChart\\ApexChart.vue' /* webpackChunkName: "pages/app/charts/apexChart/ApexChart" */))
const _9e952086 = () => interopDefault(import('..\\pages\\app\\charts\\apexChart\\ApexColumnChart.vue' /* webpackChunkName: "pages/app/charts/apexChart/ApexColumnChart" */))
const _11beffc2 = () => interopDefault(import('..\\pages\\app\\charts\\apexChart\\ApexLineChart.vue' /* webpackChunkName: "pages/app/charts/apexChart/ApexLineChart" */))
const _030c9e9d = () => interopDefault(import('..\\pages\\app\\charts\\apexChart\\ApexMixChart.vue' /* webpackChunkName: "pages/app/charts/apexChart/ApexMixChart" */))
const _0ea3ad26 = () => interopDefault(import('..\\pages\\app\\charts\\apexChart\\ApexPieChart.vue' /* webpackChunkName: "pages/app/charts/apexChart/ApexPieChart" */))
const _3966571a = () => interopDefault(import('..\\pages\\app\\charts\\apexChart\\ApexRadarChart.vue' /* webpackChunkName: "pages/app/charts/apexChart/ApexRadarChart" */))
const _8cad2f76 = () => interopDefault(import('..\\pages\\app\\charts\\apexChart\\ApexRadialBarChart.vue' /* webpackChunkName: "pages/app/charts/apexChart/ApexRadialBarChart" */))
const _5f5a02fb = () => interopDefault(import('..\\pages\\app\\charts\\apexChart\\ApexScatterChart.vue' /* webpackChunkName: "pages/app/charts/apexChart/ApexScatterChart" */))
const _3a6653f0 = () => interopDefault(import('..\\pages\\app\\charts\\apexChart\\ApexSparklineChart.vue' /* webpackChunkName: "pages/app/charts/apexChart/ApexSparklineChart" */))
const _611f7d02 = () => interopDefault(import('..\\pages\\app\\charts\\apexChart\\CustomApexChart.vue' /* webpackChunkName: "pages/app/charts/apexChart/CustomApexChart" */))
const _3baaba14 = () => interopDefault(import('..\\pages\\app\\pages\\account\\Account.vue' /* webpackChunkName: "pages/app/pages/account/Account" */))
const _4a34b2c0 = () => interopDefault(import('..\\pages\\app\\pages\\account\\AccountData.vue' /* webpackChunkName: "pages/app/pages/account/AccountData" */))
const _7ad1d516 = () => interopDefault(import('..\\pages\\app\\pages\\account\\AccountHome.vue' /* webpackChunkName: "pages/app/pages/account/AccountHome" */))
const _78d4a360 = () => interopDefault(import('..\\pages\\app\\pages\\account\\AccountPayment.vue' /* webpackChunkName: "pages/app/pages/account/AccountPayment" */))
const _61aad8b6 = () => interopDefault(import('..\\pages\\app\\pages\\account\\AccountPeople.vue' /* webpackChunkName: "pages/app/pages/account/AccountPeople" */))
const _241e1bb8 = () => interopDefault(import('..\\pages\\app\\pages\\account\\AccountPersonalInfo.vue' /* webpackChunkName: "pages/app/pages/account/AccountPersonalInfo" */))
const _1ba8df54 = () => interopDefault(import('..\\pages\\app\\pages\\account\\AccountSecurity.vue' /* webpackChunkName: "pages/app/pages/account/AccountSecurity" */))
const _7bf0dc16 = () => interopDefault(import('..\\pages\\app\\pages\\faq\\Faq.vue' /* webpackChunkName: "pages/app/pages/faq/Faq" */))
const _35ac58c0 = () => interopDefault(import('..\\pages\\app\\pages\\faq\\FaqOne.vue' /* webpackChunkName: "pages/app/pages/faq/FaqOne" */))
const _76e2e350 = () => interopDefault(import('..\\pages\\app\\pages\\faq\\FaqThree.vue' /* webpackChunkName: "pages/app/pages/faq/FaqThree" */))
const _04dcf6f4 = () => interopDefault(import('..\\pages\\app\\pages\\faq\\FaqTwo.vue' /* webpackChunkName: "pages/app/pages/faq/FaqTwo" */))
const _95b51be8 = () => interopDefault(import('..\\pages\\app\\pages\\invoice\\EditInvoice.vue' /* webpackChunkName: "pages/app/pages/invoice/EditInvoice" */))
const _7a1ac2f6 = () => interopDefault(import('..\\pages\\app\\pages\\invoice\\Invoice.vue' /* webpackChunkName: "pages/app/pages/invoice/Invoice" */))
const _c4ca224e = () => interopDefault(import('..\\pages\\app\\pages\\invoice\\InvoiceVerOne.vue' /* webpackChunkName: "pages/app/pages/invoice/InvoiceVerOne" */))
const _93fac082 = () => interopDefault(import('..\\pages\\app\\pages\\invoice\\InvoiceVerTwo.vue' /* webpackChunkName: "pages/app/pages/invoice/InvoiceVerTwo" */))
const _0e0266d2 = () => interopDefault(import('..\\pages\\app\\pages\\list\\List.vue' /* webpackChunkName: "pages/app/pages/list/List" */))
const _774bd2ae = () => interopDefault(import('..\\pages\\app\\pages\\list\\ListColumnOne.vue' /* webpackChunkName: "pages/app/pages/list/ListColumnOne" */))
const _18b10422 = () => interopDefault(import('..\\pages\\app\\pages\\list\\ListColumnRow.vue' /* webpackChunkName: "pages/app/pages/list/ListColumnRow" */))
const _562d01e6 = () => interopDefault(import('..\\pages\\app\\pages\\list\\ListColumnThree.vue' /* webpackChunkName: "pages/app/pages/list/ListColumnThree" */))
const _e098f8d8 = () => interopDefault(import('..\\pages\\app\\pages\\list\\ListColumnTwo.vue' /* webpackChunkName: "pages/app/pages/list/ListColumnTwo" */))
const _733bcf16 = () => interopDefault(import('..\\pages\\app\\pages\\pricing\\Pricing.vue' /* webpackChunkName: "pages/app/pages/pricing/Pricing" */))
const _3ceb3a0e = () => interopDefault(import('..\\pages\\app\\pages\\pricing\\PricingVerOne.vue' /* webpackChunkName: "pages/app/pages/pricing/PricingVerOne" */))
const _2b08ab71 = () => interopDefault(import('..\\pages\\app\\pages\\pricing\\PricingVerThree.vue' /* webpackChunkName: "pages/app/pages/pricing/PricingVerThree" */))
const _0c1bd842 = () => interopDefault(import('..\\pages\\app\\pages\\pricing\\PricingVerTwo.vue' /* webpackChunkName: "pages/app/pages/pricing/PricingVerTwo" */))
const _36ea8e76 = () => interopDefault(import('..\\pages\\app\\pages\\profile\\Profile.vue' /* webpackChunkName: "pages/app/pages/profile/Profile" */))
const _6ca68540 = () => interopDefault(import('..\\pages\\app\\pages\\profile\\ProfileOne.vue' /* webpackChunkName: "pages/app/pages/profile/ProfileOne" */))
const _f5e393b4 = () => interopDefault(import('..\\pages\\app\\pages\\profile\\ProfileTwo.vue' /* webpackChunkName: "pages/app/pages/profile/ProfileTwo" */))
const _7493e809 = () => interopDefault(import('..\\pages\\app\\pages\\projects\\Overview.vue' /* webpackChunkName: "pages/app/pages/projects/Overview" */))
const _0774aa8a = () => interopDefault(import('..\\pages\\app\\pages\\projects\\Projects.vue' /* webpackChunkName: "pages/app/pages/projects/Projects" */))
const _44263056 = () => interopDefault(import('..\\pages\\app\\pages\\projects\\Todo.vue' /* webpackChunkName: "pages/app/pages/projects/Todo" */))
const _07826a22 = () => interopDefault(import('..\\pages\\app\\pages\\widgets\\General.vue' /* webpackChunkName: "pages/app/pages/widgets/General" */))
const _2690407c = () => interopDefault(import('..\\pages\\app\\pages\\widgets\\WidgetCharts.vue' /* webpackChunkName: "pages/app/pages/widgets/WidgetCharts" */))
const _dc391594 = () => interopDefault(import('..\\pages\\app\\pages\\widgets\\Widgets.vue' /* webpackChunkName: "pages/app/pages/widgets/Widgets" */))
const _6f56b130 = () => interopDefault(import('..\\pages\\app\\pages\\widgets\\WidgetsTable.vue' /* webpackChunkName: "pages/app/pages/widgets/WidgetsTable" */))
const _7a152772 = () => interopDefault(import('..\\pages\\fund\\_id.vue' /* webpackChunkName: "pages/fund/_id" */))
const _be9ee4a2 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/inspire",
    component: _92205312,
    name: "inspire"
  }, {
    path: "/fund/list",
    component: _2c517816,
    name: "fund-list"
  }, {
    path: "/app/apps/Index",
    component: _31847932,
    name: "app-apps-Index"
  }, {
    path: "/app/apps/Scrumboard",
    component: _01c60888,
    name: "app-apps-Scrumboard"
  }, {
    path: "/app/charts/Charts",
    component: _fc5cdaf0,
    name: "app-charts-Charts"
  }, {
    path: "/app/dashboard/Analytic",
    component: _0f77cff3,
    name: "app-dashboard-Analytic"
  }, {
    path: "/app/dashboard/Index",
    component: _4012dfdc,
    name: "app-dashboard-Index"
  }, {
    path: "/app/ecommerce/CartDrawer",
    component: _4d3987c3,
    name: "app-ecommerce-CartDrawer"
  }, {
    path: "/app/ecommerce/Ecommerce",
    component: _0933e41e,
    name: "app-ecommerce-Ecommerce"
  }, {
    path: "/app/ecommerce/EcommerceProductCheckout",
    component: _8b7e8df2,
    name: "app-ecommerce-EcommerceProductCheckout"
  }, {
    path: "/app/ecommerce/EcommerceProductDetails",
    component: _79773e91,
    name: "app-ecommerce-EcommerceProductDetails"
  }, {
    path: "/app/ecommerce/EcommerceProductList",
    component: _37dd2cdf,
    name: "app-ecommerce-EcommerceProductList"
  }, {
    path: "/app/pages/Blank",
    component: _a9f3d1a4,
    name: "app-pages-Blank"
  }, {
    path: "/app/pages/Pages",
    component: _7e91bd9e,
    name: "app-pages-Pages"
  }, {
    path: "/app/charts/apexChart/ApexAreaChart",
    component: _20e408b4,
    name: "app-charts-apexChart-ApexAreaChart"
  }, {
    path: "/app/charts/apexChart/ApexBarChart",
    component: _4d8c46c6,
    name: "app-charts-apexChart-ApexBarChart"
  }, {
    path: "/app/charts/apexChart/ApexChart",
    component: _7d710433,
    name: "app-charts-apexChart-ApexChart"
  }, {
    path: "/app/charts/apexChart/ApexColumnChart",
    component: _9e952086,
    name: "app-charts-apexChart-ApexColumnChart"
  }, {
    path: "/app/charts/apexChart/ApexLineChart",
    component: _11beffc2,
    name: "app-charts-apexChart-ApexLineChart"
  }, {
    path: "/app/charts/apexChart/ApexMixChart",
    component: _030c9e9d,
    name: "app-charts-apexChart-ApexMixChart"
  }, {
    path: "/app/charts/apexChart/ApexPieChart",
    component: _0ea3ad26,
    name: "app-charts-apexChart-ApexPieChart"
  }, {
    path: "/app/charts/apexChart/ApexRadarChart",
    component: _3966571a,
    name: "app-charts-apexChart-ApexRadarChart"
  }, {
    path: "/app/charts/apexChart/ApexRadialBarChart",
    component: _8cad2f76,
    name: "app-charts-apexChart-ApexRadialBarChart"
  }, {
    path: "/app/charts/apexChart/ApexScatterChart",
    component: _5f5a02fb,
    name: "app-charts-apexChart-ApexScatterChart"
  }, {
    path: "/app/charts/apexChart/ApexSparklineChart",
    component: _3a6653f0,
    name: "app-charts-apexChart-ApexSparklineChart"
  }, {
    path: "/app/charts/apexChart/CustomApexChart",
    component: _611f7d02,
    name: "app-charts-apexChart-CustomApexChart"
  }, {
    path: "/app/pages/account/Account",
    component: _3baaba14,
    name: "app-pages-account-Account"
  }, {
    path: "/app/pages/account/AccountData",
    component: _4a34b2c0,
    name: "app-pages-account-AccountData"
  }, {
    path: "/app/pages/account/AccountHome",
    component: _7ad1d516,
    name: "app-pages-account-AccountHome"
  }, {
    path: "/app/pages/account/AccountPayment",
    component: _78d4a360,
    name: "app-pages-account-AccountPayment"
  }, {
    path: "/app/pages/account/AccountPeople",
    component: _61aad8b6,
    name: "app-pages-account-AccountPeople"
  }, {
    path: "/app/pages/account/AccountPersonalInfo",
    component: _241e1bb8,
    name: "app-pages-account-AccountPersonalInfo"
  }, {
    path: "/app/pages/account/AccountSecurity",
    component: _1ba8df54,
    name: "app-pages-account-AccountSecurity"
  }, {
    path: "/app/pages/faq/Faq",
    component: _7bf0dc16,
    name: "app-pages-faq-Faq"
  }, {
    path: "/app/pages/faq/FaqOne",
    component: _35ac58c0,
    name: "app-pages-faq-FaqOne"
  }, {
    path: "/app/pages/faq/FaqThree",
    component: _76e2e350,
    name: "app-pages-faq-FaqThree"
  }, {
    path: "/app/pages/faq/FaqTwo",
    component: _04dcf6f4,
    name: "app-pages-faq-FaqTwo"
  }, {
    path: "/app/pages/invoice/EditInvoice",
    component: _95b51be8,
    name: "app-pages-invoice-EditInvoice"
  }, {
    path: "/app/pages/invoice/Invoice",
    component: _7a1ac2f6,
    name: "app-pages-invoice-Invoice"
  }, {
    path: "/app/pages/invoice/InvoiceVerOne",
    component: _c4ca224e,
    name: "app-pages-invoice-InvoiceVerOne"
  }, {
    path: "/app/pages/invoice/InvoiceVerTwo",
    component: _93fac082,
    name: "app-pages-invoice-InvoiceVerTwo"
  }, {
    path: "/app/pages/list/List",
    component: _0e0266d2,
    name: "app-pages-list-List"
  }, {
    path: "/app/pages/list/ListColumnOne",
    component: _774bd2ae,
    name: "app-pages-list-ListColumnOne"
  }, {
    path: "/app/pages/list/ListColumnRow",
    component: _18b10422,
    name: "app-pages-list-ListColumnRow"
  }, {
    path: "/app/pages/list/ListColumnThree",
    component: _562d01e6,
    name: "app-pages-list-ListColumnThree"
  }, {
    path: "/app/pages/list/ListColumnTwo",
    component: _e098f8d8,
    name: "app-pages-list-ListColumnTwo"
  }, {
    path: "/app/pages/pricing/Pricing",
    component: _733bcf16,
    name: "app-pages-pricing-Pricing"
  }, {
    path: "/app/pages/pricing/PricingVerOne",
    component: _3ceb3a0e,
    name: "app-pages-pricing-PricingVerOne"
  }, {
    path: "/app/pages/pricing/PricingVerThree",
    component: _2b08ab71,
    name: "app-pages-pricing-PricingVerThree"
  }, {
    path: "/app/pages/pricing/PricingVerTwo",
    component: _0c1bd842,
    name: "app-pages-pricing-PricingVerTwo"
  }, {
    path: "/app/pages/profile/Profile",
    component: _36ea8e76,
    name: "app-pages-profile-Profile"
  }, {
    path: "/app/pages/profile/ProfileOne",
    component: _6ca68540,
    name: "app-pages-profile-ProfileOne"
  }, {
    path: "/app/pages/profile/ProfileTwo",
    component: _f5e393b4,
    name: "app-pages-profile-ProfileTwo"
  }, {
    path: "/app/pages/projects/Overview",
    component: _7493e809,
    name: "app-pages-projects-Overview"
  }, {
    path: "/app/pages/projects/Projects",
    component: _0774aa8a,
    name: "app-pages-projects-Projects"
  }, {
    path: "/app/pages/projects/Todo",
    component: _44263056,
    name: "app-pages-projects-Todo"
  }, {
    path: "/app/pages/widgets/General",
    component: _07826a22,
    name: "app-pages-widgets-General"
  }, {
    path: "/app/pages/widgets/WidgetCharts",
    component: _2690407c,
    name: "app-pages-widgets-WidgetCharts"
  }, {
    path: "/app/pages/widgets/Widgets",
    component: _dc391594,
    name: "app-pages-widgets-Widgets"
  }, {
    path: "/app/pages/widgets/WidgetsTable",
    component: _6f56b130,
    name: "app-pages-widgets-WidgetsTable"
  }, {
    path: "/fund/:id?",
    component: _7a152772,
    name: "fund-id"
  }, {
    path: "/",
    component: _be9ee4a2,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
