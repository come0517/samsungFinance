module.exports = require('../.nuxt-storybook/storybook/middleware.js')
